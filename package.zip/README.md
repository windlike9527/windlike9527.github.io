# admin

## Project setup 安装依赖，使用yarn；依赖环境node、npm
```
yarn install
```

### Compiles and hot-reloads for development, 本地开发
```
yarn serve or npm run dev
```

### Compiles and minifies for production，打包后在dist目录，部署到服务器即可
```
yarn build
```
### nginx反向代理
```
location /api {
    proxy_pass https://api.xxx.com;
}
```
### Lints and fixes files
```
yarn lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
