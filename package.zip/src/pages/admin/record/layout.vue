<template>
    <router-view></router-view>
</template>
<script>
export default {
    name: 'record',
}
</script>
<style scoped lang="scss">
</style>
