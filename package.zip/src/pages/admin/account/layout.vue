<template>
    <router-view></router-view>
</template>
<script>
export default {
    name: 'userMoneyManagementCollection',
}
</script>
<style scoped lang="scss">
</style>
