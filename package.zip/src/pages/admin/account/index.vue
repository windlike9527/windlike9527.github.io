<template>
    <div>
        <Add/>
    </div>
</template>
<script>
import Add from './add.vue'
export default {
    components: {Add},
    name: 'accountIndex',
    data() {
        return {}
    }
}
</script>